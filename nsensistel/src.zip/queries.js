module.exports = {
  "SENSITEL_EN_US" : {
        "order": "Your order number "
  },
  "SENSITEL_EN_GB" : {
        "order": "Orderado"
  }
};
