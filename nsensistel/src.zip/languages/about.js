//var query = require("./queries");

module.exports.aboutLangString = {
    "en": {
        "translation": {
		//"SENSITEL": query.SENSITEL_EN_US,
		"SKILL_NAME": "Demo",
		"WELCOME_MESSAGE": "Hello from %s "
        }
    },
    "en-US": {
        "translation": {
            //"SENSITEL" : query.SENSITEL_EN_US,
            "SKILL_NAME" : "Demo"
        }
    }
};
