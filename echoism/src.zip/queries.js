module.exports = {
  "SENSITEL_EN_US" : {
        "ceo": "Sensitel CEO Name is MS Ray",
        "address": "4800 Patrick Henry Dr. #320, Santa Clara, CA 95054",
        "order": "Your order number "
  }
};
